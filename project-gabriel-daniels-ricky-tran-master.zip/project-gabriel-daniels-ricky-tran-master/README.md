# Gabriel Daniels and Ricky Tran

App that allows friends to make a list of movies and pick one at random 
Name: Pick Something Already!

Final project for Ricky and Gabriel. Includes:
  Sprint 1 and sprint 2 files (sprint 2 is updated api endpoints)
  Js server
  HTML pages
